
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Reset default margin and padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .main-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color: #9dc183;
    color: white;
}

/* Style logo */
.logo img {
    height: 50px;
    width: auto;
}

/* Style menu navigasi */
.nav-menu ul {
    display: flex;
    gap: 20px;
}

.nav-menu a {
    color: white;
    font-size: 16px;
    font-weight: bold;
    transition: color 0.3s ease;
}

.nav-menu a:hover {
    color: #ffa500; /* Warna efek hover */
}

        /* Body styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        /* Container for the dashboard */
        .dashboard {
            display: flex;
            height: 100vh;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #9dc183;
            color: white;
            padding: 20px;
            height: 100%;
        }

        .sidebar ul {
            list-style-type: none;
        }

        .sidebar ul li {
            margin: 10px 0;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            font-size: 18px;
        }

        /* Main content area */
        .main-content {
            flex: 1;
            padding: 20px;
        }

        /* Header */
        header h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        /* Overview section */
        .overview {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }

        .card p {
            font-size: 24px;
            font-weight: bold;
        }

        /* Recent Activity Section */
        .recent-activity {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .recent-activity h2 {
            font-size: 20px;
            margin-bottom: 20px;
        }

        .recent-activity ul {
            list-style-type: none;
        }

        .recent-activity ul li {
            margin: 10px 0;
            font-size: 16px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .overview {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 480px) {
            .overview {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<header class="main-header">
        <div class="logo">
        <img src="img/bonet.png" alt="Logo" />
        <img src="img/logo1.jpg.png" alt="Logo" />
        </div>
        <nav class="nav-menu">
            <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
           <li><a href="profil.php">Profil</a></li>
           <li><a href="data-image.php">Data Foto</a></li>
           <li><a href="Keluar.php">Keluar</a></li>
           <li><a href="category.php">Category</a></li>
            </ul>
        </nav>
    </header>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <ul>
                <li><a href="#">Dashboard</a></li>
                <li><a href="#">Users</a></li>
                <li><a href="#">Orders</a></li>
                <li><a href="#">Settings</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <header>
                <h1>Welcome to Admin Dashboard</h1>
            </header>

            <div class="overview">
                <div class="card">
                    <h2>Total Users</h2>
                    <p>1500</p>
                </div>
                <div class="card">
                    <h2>Total Orders</h2>
                    <p>320</p>
                </div>
                <div class="card">
                    <h2>Total Revenue</h2>
                    <p>$2300</p>
                </div>
            </div>

            <div class="recent-activity">
                <h2>Recent Activity</h2>
                <ul>
                    <li>User John Doe placed an order.</li>
                    <li>User Jane Smith updated profile.</li>
                    <li>New user registered: Adam Lee.</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
<?php
    include 'db.php';
	$kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
	$a = mysqli_fetch_object($kontak);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Website dengan Video Pengenalan</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style>/* Resetting default margin and padding */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body {
  height: 100%;
  font-family: Arial, sans-serif;
  background-color: #fff;
}

/* Styling untuk video perkenalan */
.video-intro {
  position: relative;
  width: 100%;
  height: 100vh; /* Menggunakan tinggi penuh layar */
  overflow: hidden;
}

#intro-video {
  object-fit: cover;
  width: 100%;
  height: 100%;
  display: block;
}

/* Navbar Styling */
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #9DC183; /* Latar belakang solid untuk navbar */
  color: white;
  padding: 15px 0;
  z-index: 10; /* Agar navbar di atas video */
}

.navbar ul {
  list-style-type: none;
  text-align: center;
}

.navbar ul li {
  display: inline;
  margin: 0 20px;
}

.navbar ul li a {
  color: white;
  text-decoration: none;
  font-size: 18px;
  text-transform: uppercase;
}

.navbar ul li a:hover {
  border-bottom: 2px solid white;
}
.img{
  margin-left: 20px;
}
/* Styling untuk header */
.header {
  position: relative;
  z-index: 1; /* Agar header di atas video */
  text-align: center;
  padding: 50px 20px;
  color: white;
  background: #9dc183; /* Transparansi untuk background header */
}

.header h1 {
  font-size: 3em;
  margin-bottom: 20px;
}

.header p {
  font-size: 1.5em;
}
body, ul, li, a {
    margin: 0;
    padding: 0;
    list-style: none;
    text-decoration: none;
}

/* Style header */
.main-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color: #9dc183;
    color: white;
}

/* Style logo */
.logo img {
    height: 50px;
    width: auto;
}

/* Style menu navigasi */
.nav-menu ul {
    display: flex;
    gap: 20px;
}

.nav-menu a {
    color: white;
    font-size: 16px;
    font-weight: bold;
    transition: color 0.3s ease;
}

.nav-menu a:hover {
    color: #ffa500; /* Warna efek hover */
}
/* Styling untuk teks di bawah video */
.footer-text {
  text-align: center;
  padding: 30px 20px;
  background-color: #9DC183;
  color: white;
  font-size: 1.2em;
}
</style>
</head>
<body>
<header class="main-header">
        <div class="logo">
        <img src="img/bonet.png" alt="Logo" />
        <img src="img/logo1.jpg.png" alt="Logo" />
        </div>
        <nav class="nav-menu">
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
  <!-- Video Pengenalan -->
  <div class="video-intro">
    <video id="intro-video" autoplay muted loop>
      <source src="img/aknb.mp4" type="video/mp4">
    </video>
  </div>
  
  <!-- Navbar -->
  <!-- <nav class="navbar">
    <div class="img">
    <img controls width="100" height="70" <source src="img/aknb.jpeg" class="logo">
  <img controls width="100" height="70" <source src="img/bonet.jpg" class="logo">
    </div>
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#">About</a></li>
      <li><a href="#">Services</a></li>
      <li><a href="#">Contact</a></li>
    </ul>
  </nav> -->

  <!-- Header dengan Teks -->
  <header class="header">
    <h1>Selamat Datang di Website Kami</h1>
    <p>Website ini menggunakan video untuk memperkenalkan diri.</p>
  </header>
  <div class="container">
    <h3>Foto Terbaru</h3>
    <div class="box">
       <?php
           $foto = mysqli_query($conn, "SELECT * FROM tb_image WHERE image_status = 1 ORDER BY image_id DESC LIMIT 8");
           if(mysqli_num_rows($foto) > 0){
               while($p = mysqli_fetch_array($foto)){
       ?>
       <a href="detail-image.php?id=<?php echo $p['image_id'] ?>">
       <div class="col-4">
           <img src="foto/<?php echo $p['image'] ?>" height="150px" />
           <p class="nama"><?php echo substr($p['image_name'], 0, 30)  ?></p>
           <p class="admin">Nama User : <?php echo $p['admin_name'] ?></p>
           <p class="nama"><?php echo $p['date_created']  ?></p>
       </div>
       </a>
       <?php }}else{ ?>
           <p>Foto tidak ada</p>
       <?php } ?>
    </div>
 </div>
 
  <!-- Teks di Bawah Video -->
  <div class="footer-text">
    <p>Terima kasih telah mengunjungi website kami. Kami harap Anda menemukan informasi yang Anda cari!</p>
  </div>

</body>
</html>